package com.example.buatuts

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class budayaAdapter(private val context: Context, private val budaya: List<Budaya>, val listener: (Budaya) -> Unit)
    : RecyclerView.Adapter<budayaAdapter.budayaviewHolder>(){
    class budayaviewHolder(view: View): RecyclerView.ViewHolder(view) {

        val imgbudaya = view.findViewById<ImageView>(R.id.img_item_photo)
        val namabudaya = view.findViewById<TextView>(R.id.tv_item_name)
        val deskripsi = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindView(budaya: Budaya, listener: (Budaya) -> Unit) {
            imgbudaya.setImageResource(budaya.imgbudaya)
            namabudaya.text = budaya.namabudaya
            deskripsi.text = budaya.deskripsi
            itemView.setOnClickListener{
                listener(budaya)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): budayaviewHolder {
        return budayaviewHolder(
            LayoutInflater.from(context).inflate(R.layout.daftar_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: budayaviewHolder, position: Int) {
        holder.bindView(budaya[position],listener)
    }

    override fun getItemCount(): Int = budaya.size
    }

