package com.example.buatuts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val budayaList = listOf<Budaya>(
            Budaya(
                R.drawable.ngaben,
                namabudaya = "Upcara Ngaben - Bali",
                deskripsi = "Ngaben merupakan salah satu upacara yang dilakukan oleh umat Hindu" +
                        "di Bali dan tergolong sebagai upacara" +
                        "Pitra Yadnya (upacara yang ditunjukkan kepada Leluhur)."
            ),
            Budaya(
                R.drawable.peucicap,
                namabudaya = "Peucicap - Aceh",
                deskripsi = "Peucicap merupakan salah satu dari serangkaian upacara adat Orang Aceh yang dilakukan pasca ibu melahirkan. Pada Peucicap bayi diperkenalkan beberapa rasa makanan untuk yang pertama kalinya: asam, asin dan manis. Tradisi ini seperti latihan buat bayi agar mampu membedakan antara satu rasa dengan rasa yang lainnya."
            ),
            Budaya(
                R.drawable.padusan,
                namabudaya = "Padusan - Jawa Tengah",
                deskripsi = "Padusan dikenal sebagai semacam upacara bersih diri yang dilakukan menjelang bulan puasa"
            ),
            Budaya(
                R.drawable.gawai,
                namabudaya = "Gawai - Kalimantan Barat",
                deskripsi = "Gawai Dayak merupakan perayaan yang diadakan di Kalimantan Barat dan Sarawak, Malaysia oleh suku asli Kalimantan Barat dan Sarawak, terutama Iban dan Dayak Darat."
            ),
            Budaya(
                R.drawable.seren_taun,
                namabudaya = "Seren Taun - Jawa Barat",
                deskripsi = "Seren taun adalah upacara adat panen padi masyarakat Sunda yang dilakukan setiap tahun."
            ),
            Budaya(
                R.drawable.sanepen,
                namabudaya = "Sanepen - Papua",
                deskripsi =  "Sanepen merupakan prosesi pernikahan ala suku Biak - papua"
            )
        )

        val recyclerView = findViewById<RecyclerView>(R.id.list_budaya)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = budayaAdapter(this, budayaList){
            val intent = Intent (this, DetailBudayaActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
}