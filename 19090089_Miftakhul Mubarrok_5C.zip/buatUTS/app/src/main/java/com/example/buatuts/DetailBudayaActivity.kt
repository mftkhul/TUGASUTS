package com.example.buatuts

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailBudayaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_budaya)

        val budaya = intent.getParcelableExtra<Budaya>(MainActivity.INTENT_PARCELABLE)

        val imgbudaya = findViewById<ImageView>(R.id.img_item_photo)
        val namabudaya = findViewById<TextView>(R.id.tv_item_name)
        val deskripsi = findViewById<TextView>(R.id.tv_item_description)

        imgbudaya.setImageResource(budaya?.imgbudaya!!)
        namabudaya.text = budaya.namabudaya
        deskripsi.text = budaya.deskripsi
    }
}