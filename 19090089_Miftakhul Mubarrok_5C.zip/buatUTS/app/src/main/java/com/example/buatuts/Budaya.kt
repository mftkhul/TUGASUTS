package com.example.buatuts

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Budaya(
    val imgbudaya: Int,
    val namabudaya: String,
    val deskripsi: String
) :Parcelable
